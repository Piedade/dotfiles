// Glaze Library
// For the license information refer to glaze.hpp

#pragma once

#include "glaze/msgpack/read.hpp"
#include "glaze/msgpack/write.hpp"
